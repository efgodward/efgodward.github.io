Task
========================

Your Grandma wants you to publish her famous cookie recipe on a simple site. She's typed it out for you in this document (she's so nice). 

She absolutely wants the directions to appear in order in a numbered list. The cookies won't taste good if you don't get the order right. (hint you need an ordered list).

Your Grandpa happens to be an...ok...Graphic Designer and gave you the following specs to style:

Cookie Recipe CSS
=================

- The background color for the page is #c8deec
- The color for the text reading "Nutrition Information" is #887
- The font family for the h1, h3 and h4 is Courier New
- The font family for the h2 is Century Gothic
- The font family for all other elements is Helvetica Neue
- The font weight for the link is bold 
- Bonus: The border on the page and around the image is black

The Cookie Recipe
=================

The Best Chocolate Chip Cookies
Recipe by: My Grandma
Prep Time: 45 Min

INGREDIENTS
1 1/2 cup (3 sticks) softened butter, 1 cup brown sugar, 1 cup granulated sugar, 1 Tbl vanilla instant pudding powder, 2 Tbl milk, 2 Tbl vanilla extract, 2 eggs, 4 cups all purpose flour, 2 tsp baking soda, 1/2 tsp salt, 4 cups chocolate chips, 1 cup chopped walnuts or pecans(optional)

How to make Mama’s Recipe: Preheat oven to 350 degrees Beat butter and sugars together until light and fluffy. Stir in pudding mix milk and vanilla extract. Beat in eggs. Add dry ingredients and stir until combined.
Stir in chocolate chips and nuts.Place 1 1/2 inch balls of dough 2 inches apart on an un greased cookie sheet. Bake 8-10 minutes or until golden brown.


Nutrition Information

Probably bad for you, but who cares. MMMMMM COOKIES!!!! nom nom nom

So, in case you didn't know, your grandma didn't actually make this recipe, it was altered from Open Source Recipe "http://www.opensourcefood.com/people/Amanori/recipes/mamas-recipe-the-best-chocolate-chip-cookies"
Sorry to break the news. <!--You must include the link in your final webpage -->

