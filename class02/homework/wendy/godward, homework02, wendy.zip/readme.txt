Your mission is to recreate the two attached reference images in about-comp and resume-comp. 

Create two well-constructed HTML file linked to a CSS file or files. 

The pages should link to eachother.
Do your best to match the provided reference image.  

San-serif font: Helvetica;
Mint Green color: #33CC99;

//
COPY:
//

ABOUT PAGE:

Wendy G. Bite
About Me | Resume
About Me


The series revolves around four older, single women (three widows and one divorcée) sharing a house in Miami, Florida. The owner of the house is a widow named Blanche Devereaux (Rue McClanahan), who was joined by fellow widow Rose Nylund (Betty White) and divorcée Dorothy Zbornak (Bea Arthur). They both responded to a room-for-rent ad on the bulletin board of a local grocery store. The three were soon joined by Dorothy's mother, Sophia Petrillo (Estelle Getty), after the retirement home where she lived, Shady Pines, burned down.

Thank You for being a friend. Travel down a road and back again. Your heart is true, you're a pal and a confidante.And if you threw a party, invited everyone you knew, you would see the biggest gift would be from me and the card attached would say, Thank You For Being a Friend!

Facebook | Twitter | Instagram | LinkedIn


RESUME PAGE:

Wendy G. Bite
About Me | Resume
Resume
I recently graduated from a Web Development course at General Assembly where I increased my typing speed from 10 words per minute on my type writer to 100 words per minute on my new MacBook Pro. They also taught me how to be an awesome Web Developer. During my spare time, I enjoy senior water aerobics, pickling, and spending time with my great grand children.

RELEVANT EXPERIENCE
Web Developer GitHub 2013 - present
Building a user friendly interface that is easy for beginner programmers to use and learn the benefits of git.

Copy Editor, Complaint.ly 2012 - 2013
Reviewed, organize and filed multiple complaints to neighbors, local stores, and government officials. (self employed)

Senior Vice President, The Golden Girls Appreciation Society 1985 - 1992
Managed a team of three and over saw day to day operations at The Golden Girls Retirement Facility in Miami.

Certified Mint Candy and Freshly Baked Cookies Distributor. 1960
Won multiple awards for my secret chocolate chip recipies. My grand children enjoy them too :)

EDUCATION
General Assembly - 2018
Queens College - B.A. 1923
Brooklyn Etiquette School For Girls - 1920 (Honors)
Facebook | Twitter | Instagram | LinkedIn